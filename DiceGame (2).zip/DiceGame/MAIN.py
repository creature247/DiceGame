##imports
import time
import sys
import pygame
from random import randint
from pygame import mixer
from pygame import mixer

import PasswordVerification

#Changes the song playing (Clicking button too fast may result in it breaking)
def MusicChange(NumOfSong):
    if NumOfSong > 3:
        NumOfSong -= 3
    mixer.music.load("Music" + str(NumOfSong) + ".mp3")
    mixer.music.play()
# Gets the usernames
print("Welcome to the Dice rolling game!")
UserName1 = input("What should player one be called? \n")
UserName2 = input("What should player two be called? \n")

#initialises all of the modules we are using and defines all the variables
PlayerOneWins = False
PlayerTwoWins = False
SongNum = 0
Player = 0
pygame.init()
pygame.font.init()
pygame.display.set_caption('Dice Rolling game.')
Display_Height = 1000
Display_Width = 500
screen = pygame.display.set_mode([Display_Height, Display_Width])
BLUE = (0, 0, 255)
WHITE = (255,255,255)
BLACK = (0,0,0)
SIZEOFDICESPOTS = 50
Scores = []
Scores2 = []
ExtraDiceRolls = []
ExtraDiceRollsTwo = []
score = 0
scoreTwo = 0
Green = (0,255,0)
Volume = 0.5


#starts the first song playing
mixer.music.set_volume(Volume)
mixer.init()
MusicChange(1)
#These draw the dice rolls on the screen, and are all essentially the same idea
def SixOnAD6():
    #Green spots go underneath the blue ones to make a green ring around the outside of the circles
    pygame.draw.circle(screen, Green, (400, 100), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (100, 100), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (400, 250), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (100, 250), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (400, 400), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (100, 400), SIZEOFDICESPOTS+10)
    
    pygame.draw.circle(screen, BLUE, (400, 100), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (100, 100), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (400, 250), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (100, 250), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (400, 400), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (100, 400), SIZEOFDICESPOTS)

def FourOnAD6():
    pygame.draw.circle(screen, Green, (400, 100), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (100, 100), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (400, 400), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (100, 400), SIZEOFDICESPOTS+10)
    
    pygame.draw.circle(screen, BLUE, (400, 100), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (100, 100), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (400, 400), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (100, 400), SIZEOFDICESPOTS)
    
def ThreeOnAD6():
    
    pygame.draw.circle(screen, Green, (100, 100), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (250, 250), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (400, 400), SIZEOFDICESPOTS+10)
    
    pygame.draw.circle(screen, BLUE, (100, 100), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (250, 250), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (400, 400), SIZEOFDICESPOTS)

def FiveOnAD6():
    pygame.draw.circle(screen, Green, (400, 100), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (100, 100), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (250, 250), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (400, 400), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (100, 400), SIZEOFDICESPOTS+10)
    
    pygame.draw.circle(screen, BLUE, (100, 100), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (250, 250), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (400, 400), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (100, 400), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (400, 100), SIZEOFDICESPOTS)

def TwoOnAD6():
    pygame.draw.circle(screen, Green, (100, 100), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (400, 400), SIZEOFDICESPOTS+10)

    pygame.draw.circle(screen, BLUE, (100, 100), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (400, 400), SIZEOFDICESPOTS)

def OneOnAD6():
    pygame.draw.circle(screen, Green, (250, 250), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, BLUE, (250, 250), SIZEOFDICESPOTS)

#Same code as before but on the other side of the screen
def SixOnAD6Two():
    pygame.draw.circle(screen, Green, (900, 100), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (600, 100), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (900, 250), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (600, 250), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (900, 400), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (600, 400), SIZEOFDICESPOTS+10)
    
    pygame.draw.circle(screen, BLUE, (900, 100), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (600, 100), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (900, 250), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (600, 250), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (900, 400), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (600, 400), SIZEOFDICESPOTS)

def FourOnAD6Two():
    pygame.draw.circle(screen, Green, (900, 400), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (900, 100), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (600, 100), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (600, 400), SIZEOFDICESPOTS+10)
    
    pygame.draw.circle(screen, BLUE, (900, 100), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (600, 100), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (900, 400), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (600, 400), SIZEOFDICESPOTS)
    
def ThreeOnAD6Two():
    pygame.draw.circle(screen, Green, (900, 400), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (600, 100), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (750, 250), SIZEOFDICESPOTS+10)
    
    pygame.draw.circle(screen, BLUE, (600, 100), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (750, 250), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (900, 400), SIZEOFDICESPOTS)

def FiveOnAD6Two():
    pygame.draw.circle(screen, Green, (900, 400), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (600, 400), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (900, 100), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (600, 100), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (750, 250), SIZEOFDICESPOTS+10)
    
    pygame.draw.circle(screen, BLUE, (600, 100), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (750, 250), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (900, 400), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (600, 400), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (900, 100), SIZEOFDICESPOTS)

def TwoOnAD6Two():
    pygame.draw.circle(screen, Green, (900, 400), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, Green, (600, 100), SIZEOFDICESPOTS+10)
    
    pygame.draw.circle(screen, BLUE, (600, 100), SIZEOFDICESPOTS)
    pygame.draw.circle(screen, BLUE, (900, 400), SIZEOFDICESPOTS)

def OneOnAD6Two():
    pygame.draw.circle(screen, Green, (750, 250), SIZEOFDICESPOTS+10)
    pygame.draw.circle(screen, BLUE, (750, 250), SIZEOFDICESPOTS)

#Picks the rolls
def PickRolls(PlayerNum):
    screen.fill((0, 0, 0))
    score = 0
    #Picks a random number between 1 and 6, and displays that dice roll on the coresponding side of the screen
    #Also adds 1 to the "score" counter
    DiceRoll = randint(1,6)
    if DiceRoll == 1:
        OneOnAD6()
        score = 1
    if DiceRoll == 2:
        TwoOnAD6()
        score = 2
    if DiceRoll == 3:
        ThreeOnAD6()
        score = 3
    if DiceRoll == 4:
        FourOnAD6()
        score = 4
    if DiceRoll == 5:
        FiveOnAD6()
        score = 5
    if DiceRoll == 6:
        SixOnAD6()
        score = 6
    #Adds one to the score2 counter  
    score2 = 0
    DiceRoll2 = randint(1,6)
    if DiceRoll2 == 1:
        OneOnAD6Two()
        score2 = 1
    if DiceRoll2 == 2:
        TwoOnAD6Two()
        score2 = 2
    if DiceRoll2 == 3:
        ThreeOnAD6Two()
        score2 = 3
    if DiceRoll2 == 4:
        FourOnAD6Two()
        score2 = 4
    if DiceRoll2 == 5:
        FiveOnAD6Two()
        score2 = 5
    if DiceRoll2 == 6:
        SixOnAD6Two()
        score2 = 6
    #makes a variable called CombinedScore and makes it the same as the dice rolls combined (this is the round score)
    CombinedScore = DiceRoll + DiceRoll2
    #If it is player one's turn, print player one's scores          
    if PlayerNum == 1:
        Scores.append(CombinedScore)
        print("Player One's scores are: ")
        print(Scores)
    #If it is player two's turn, print player two's scores
    if PlayerNum == 2:
        Scores2.append(CombinedScore)
        print("Player Two's scores are: ")
        print(Scores2)

    #updates the screen
    pygame.display.update()
    #makes the game pause for one second
    time.sleep(1)
    #Figues out if extra dice need to be rolled
    if DiceRoll == DiceRoll2:
        if PlayerNum == 1:
            ExtraDice(1)
        if PlayerNum == 2:
            ExtraDice(2)


#Rolls extra dice
def ExtraDice(PlayerNum):
    RollFromMainProgram = randint(1,6)
    RollFromMainProgramTwo = randint(1,6)
    screen.fill((0, 0, 0))

    if RollFromMainProgram == 1:
        OneOnAD6()
        if PlayerNum == 1:
            ExtraDiceRolls.append(RollFromMainProgram)
        if PlayerNum == 2:
            ExtraDiceRollsTwo.append(RollFromMainProgram)

    if RollFromMainProgram == 2:
        TwoOnAD6()
        if PlayerNum == 1:
            ExtraDiceRolls.append(RollFromMainProgram)
        if PlayerNum == 2:
            ExtraDiceRollsTwo.append(RollFromMainProgram)

    if RollFromMainProgram == 3:
        ThreeOnAD6()
        if PlayerNum == 1:
            ExtraDiceRolls.append(RollFromMainProgram)
        if PlayerNum == 2:
            ExtraDiceRollsTwo.append(RollFromMainProgram)

    if RollFromMainProgram == 4:
        FourOnAD6()
        if PlayerNum == 1:
            ExtraDiceRolls.append(RollFromMainProgram)
        if PlayerNum == 2:
            ExtraDiceRollsTwo.append(RollFromMainProgram)

    if RollFromMainProgram == 5:
        FiveOnAD6()
        if PlayerNum == 1:
            ExtraDiceRolls.append(RollFromMainProgram)
        if PlayerNum == 2:
            ExtraDiceRollsTwo.append(RollFromMainProgram)

    if RollFromMainProgram == 6:
        SixOnAD6()
        if PlayerNum == 1:
            ExtraDiceRolls.append(RollFromMainProgram)
        if PlayerNum == 2:
            ExtraDiceRollsTwo.append(RollFromMainProgram)
    #prints extra dice results
    if PlayerNum == 1:
        print("Player One's extra dice rolls have been: ")
        print(ExtraDiceRolls)
    if PlayerNum == 2:
        print("Player Two's extra dice rolls have been: ")
        print(ExtraDiceRollsTwo)
    #updates the sceen
    pygame.display.flip()
    #pauses the game for a second
    time.sleep(1)
    return
        
    
#Import images and loads them and also rescales the image to the scale of the background
#(many of the images arent used)
BG_IMG = pygame.image.load("BG-IMG.png")
BG_IMG = pygame.transform.scale(BG_IMG, (1000, 500))
BG_IMG2 = pygame.image.load("BG-IMG2.jpg")
BG_IMG2 = pygame.transform.scale(BG_IMG2, (1000, 500))
BG_IMG3 = pygame.image.load("BG-IMG3.jpg")
BG_IMG3 = pygame.transform.scale(BG_IMG3, (1000, 500))
#Calculates scores overall
def CalcScores():
    #Amount of rounds == the amount of dice that player 1 has rolled
    Rounds = len(Scores)
    CalculatedScoreOne = 0
    CalculatedScoreTwo = 0
    Score = 0
    #If the score is even, add 10, it it's odd, minus 5
    for i in range(0,len(Scores)):
            
        if Scores[i] % 2 == 0:
            Score = Scores[i] + 10
            CalculatedScoreOne += Score 

        if Scores[i] % 2 == 1:
            Score = Scores[i] -5
            CalculatedScoreOne += Score
    #adds the extra dice on (these are not subject to the even / odd rules)
    for i in range(0,len(ExtraDiceRolls)):
        CalculatedScoreOne += ExtraDiceRolls[i]
    
    #Does the same but for player 2
    for i in range(0,len(Scores2)):
            
        if Scores2[i] % 2 == 0:
            Score = Scores2[i] + 10
            CalculatedScoreTwo += Score 

        if Scores2[i] % 2 == 1:
            Score = Scores2[i] -5
            CalculatedScoreTwo += Score

    for i in range(0,len(ExtraDiceRollsTwo)):
        CalculatedScoreTwo += ExtraDiceRollsTwo[i]
    #prints both user's end score 
    print(UserName1 + "'s score is " + str(CalculatedScoreOne))
    print(UserName2 + "'s score is " + str(CalculatedScoreTwo))

    #when the game is over, print who has won.
    if Rounds > 5 or CalculatedScoreOne < 0 or CalculatedScoreTwo < 0: 
        if CalculatedScoreOne > CalculatedScoreTwo:
            print(UserName1 + " WINS!!!")
            time.sleep(10)
            exit()
        if CalculatedScoreOne < CalculatedScoreTwo:
            print(UserName2 + " WINS!!!")
            exit()
            

    

      

def TitleScreen(Name):
    #imports a font
    font = pygame.font.Font('freesansbold.ttf', 22)
    #makes running true
    running = True
    #makes player = name
    Player = Name
    #figures out the players name based off of the player number
    if Player == 1:
        Name = UserName1
    if Player == 2:
        Name = UserName2
    #sets different backgrounds for different players
    if Player == 1:
        BG_IMG_USED = BG_IMG3
    if Player == 2:
        BG_IMG_USED = BG_IMG2
    #while running loop
    while running:
        #update the screen
        pygame.display.update()
        #puts the BG onto the background
        screen.blit(BG_IMG_USED, (0,0))
        #puts some text in the middle of the screen
        text = font.render( str(Name) + ', Roll dice = click, Exit = "E" Settings = "S"', True, WHITE, BLACK)
        textRect = text.get_rect()
        textRect.center = (Display_Height // 2, Display_Width // 2)
        screen.blit(text, textRect)

        #figures out if the user is pressing the required button then takes them to that section
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.QUIT
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    running = False
                    PickRolls(Player)
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_e:
                    running = False
                    pygame.QUIT
                    exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_s:
                    Settings()
                    pygame.display.update()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_a:
                    print("Go to achievements")
                    
                    
        

#Settings screen
def Settings():
    #makes SongNum a global variable
    global  SongNum
    #Puts all of the text on the screen 
    font = pygame.font.Font('freesansbold.ttf', 22)
    BG_IMG_USED = BG_IMG
    screen.blit(BG_IMG_USED, (0,0))
    text = font.render('To Move on to the next song, press "W"', True, WHITE, BLACK)
    textRect = text.get_rect()
    textRect.center = (Display_Height // 4, 100)
    screen.blit(text, textRect)
    text = font.render('To Change the volume of music, press "F" for louder and "D" for quieter', True, WHITE, BLACK)
    textRect.center = (Display_Height // 4, 150)
    screen.blit(text, textRect)
    text = font.render('To return to the menu, press "R"', True, WHITE, BLACK)
    textRect.center = (Display_Height // 4, 200)
    screen.blit(text, textRect)
    #imports Volume as a global variable
    global Volume
    #running loop
    running = True
    while running:
        #gets the events and sees if keys are pressed
        for event in pygame.event.get():
            #Makes the "x" button in the corner actually close the program
            if event.type == pygame.QUIT:
                running = False
                pygame.QUIT
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_w:
                    #Changes the number
                    SongNum += 1
                    MusicChange(SongNum)
                if event.key == pygame.K_r:
                    return
                    
                if event.key == pygame.K_f:
                    #if f is pressed, make the song louder
                    Volume += 0.1
                    mixer.music.set_volume(Volume)
                if event.key == pygame.K_d:
                    #if d is pressed, make the song quieter
                    Volume -= 0.1
                    mixer.music.set_volume(Volume)
        #updates the screen
        pygame.display.update()

#this section dosen't work yet
def Scoreboard():
    print("This section is not working yet, try again later")
##    Scoreboard = []
##    with open('Scoreboard.txt') as lines:
##      for line in lines:
##          Scoreboard.append(line)
##          Scoreboard.sort()
##          print(Scoreboard)
##    for i in range(0,len(Scoreboard)):
##        f = open("Scoreboard.txt", "w")
##        f.write(Scoreboard[i])
##        f.close()
          
        
    
          

        
            
          
#main loop                
def MainLoop():
    running = True
    #run loop
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.QUIT
                exit()
                running = False
        #calls the functions       
        TitleScreen(1)
        TitleScreen(2)
        CalcScores()

    
#calls the main loop
MainLoop()
#exits
pygame.QUIT        

        

    






        
            







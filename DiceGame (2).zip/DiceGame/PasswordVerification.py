#Imports hashlib
import hashlib
#Defines the variables salt and HashedPassword
salt = ''
HashedPassword = '' 

    
#Reads the file salt.txt and makes the variable salt whatever's on the first line
with open('salt.txt') as lines:
  for line in lines:
      salt = line
      
      
#Reads the file hash.txt and makes the variable HashedPassword whatever's on the first line
      
with open('hash.txt') as lines:      
  for line in lines:
      HashedPassword = line
      
      


#asks for an input from the user
password = input('Enter the password: ')
#adds the salt to the user input
password = password + str(salt)
#encodes the result
h = hashlib.sha1(password.encode())
#sets the encoded result of the User's input and the salt as HashedPasswordCORRECT
HashedPasswordCORRECT = (h.hexdigest())


#sees if the user's input is the same as the original password
print(HashedPasswordCORRECT + " is the correct password")
if HashedPassword == HashedPasswordCORRECT:
    print("The correct password has been entered")
if HashedPassword != HashedPasswordCORRECT:
    exit()

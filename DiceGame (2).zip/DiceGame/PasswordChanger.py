#imports the library hashlib
import hashlib
from random import randint
#opens the file hash.txt and if it does not exist, it creates it
f = open('hash.txt', 'w+')
#Asks the user for an input and sets user_entered_password to it
user_entered_password = input('What would you like the password to be?:')
#Makes a variable called salt and assigns it a random number between 1 and 500
salt = randint(1,500)
#Adds the salt on to the end of the password
db_password = user_entered_password + str(salt)
#Encodes the salted password using the hashlib library
h = hashlib.sha1(db_password.encode())
#Assigns this to a variable called HashedPassword
HashedPassword = (h.hexdigest())
#Writes the hashed and salted password into the file hash.txt on the first line
line = str(HashedPassword)
f.write(line)
f.close()
#Writes the salt on it's own in a file called salt.txt on the first line
f = open('salt.txt', 'w+')
line = str(salt)
f.write(line)
f.close()



